import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const BOOST_OPTIONS = [{label:'x2',value:2},{label:'x3',value:3},{label:'x5',value:5}];

export default function BoostScreen() {
  const [selected,setSelected] = useState(1);

  useEffect(()=>{ (async()=>{ const b = await AsyncStorage.getItem('boostMultiplier'); if(b) setSelected(Number(b)); })(); },[]);

  const selectBoost = async (v) => { setSelected(v); await AsyncStorage.setItem('boostMultiplier', String(v)); };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>اختر المضاعف</Text>
      {BOOST_OPTIONS.map(item=>(
        <TouchableOpacity key={item.value} style={[styles.card, selected===item.value && styles.selected]} onPress={()=>selectBoost(item.value)}>
          <Text style={styles.label}>{item.label}</Text>
          {selected===item.value && <Text style={styles.check}>✔</Text>}
        </TouchableOpacity>
      ))}
    </View>
  );
}

const styles=StyleSheet.create({
  container:{flex:1,padding:20,alignItems:'center',backgroundColor:'#f8f9fa'},
  title:{fontSize:22,fontWeight:'bold',marginBottom:20},
  card:{width:'80%',padding:20,marginVertical:10,borderRadius:10,backgroundColor:'#fff',flexDirection:'row',justifyContent:'space-between',alignItems:'center',borderWidth:1,borderColor:'#ccc'},
  selected:{borderColor:'#007bff',borderWidth:2},
  label:{fontSize:18,fontWeight:'bold'},
  check:{fontSize:18,color:'#007bff'}
});

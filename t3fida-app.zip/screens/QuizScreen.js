import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

const QUESTIONS = [
  { q:'ما هي عاصمة فرنسا؟', choices:['باريس','لندن','برلين','مدريد'], a:0 },
  { q:'2+2؟', choices:['3','4','5','6'], a:1 },
  { q:'أكبر كوكب؟', choices:['الأرض','المشتري','المريخ','زحل'], a:1 }
];

export default function QuizScreen({ navigation }) {
  const [index,setIndex]=useState(0);
  const [score,setScore]=useState(0);
  const [selected,setSelected]=useState(null);

  const choose = (i) => {
    setSelected(i);
    if(i===QUESTIONS[index].a) setScore(s=>s+1);
    setTimeout(()=> {
      if(index+1<QUESTIONS.length) { setIndex(index+1); setSelected(null); }
      else navigation.navigate('Result',{score});
    },800);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.q}>{QUESTIONS[index].q}</Text>
      {QUESTIONS[index].choices.map((c,i)=>(
        <TouchableOpacity key={i} style={[styles.option, selected===i && (i===QUESTIONS[index].a?styles.correct:styles.wrong)]} onPress={()=>choose(i)} disabled={selected!==null}>
          <Text>{c}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container:{flex:1,padding:20,justifyContent:'center'},
  q:{fontSize:20,marginBottom:12,textAlign:'center'},
  option:{padding:12,borderWidth:1,borderColor:'#ddd',borderRadius:8,marginBottom:8},
  correct:{backgroundColor:'green'},
  wrong:{backgroundColor:'red'}
});

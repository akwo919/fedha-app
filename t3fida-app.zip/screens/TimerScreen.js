import React, { useEffect, useState, useRef } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Progress from 'react-native-progress';

const POINTS_ON_COMPLETE = 10;
const DAY_SECONDS = 24 * 60 * 60;

export default function TimerScreen({ navigation }) {
  const [secondsLeft, setSecondsLeft] = useState(DAY_SECONDS);
  const [isActive, setIsActive] = useState(false);
  const intervalRef = useRef(null);

  useEffect(() => {
    (async () => {
      const start = await AsyncStorage.getItem('timerStart');
      const now = Math.floor(Date.now()/1000);
      if (start) {
        const elapsed = now - Number(start);
        const remain = DAY_SECONDS - elapsed;
        if (remain <= 0) {
          await grantPoints();
          setSecondsLeft(0);
        } else {
          setSecondsLeft(remain);
        }
      } else {
        setSecondsLeft(DAY_SECONDS);
      }
    })();
  }, []);

  useEffect(()=> {
    if (isActive) {
      intervalRef.current = setInterval(()=> {
        setSecondsLeft(prev => {
          if (prev <= 1) {
            clearInterval(intervalRef.current);
            grantPoints();
            setIsActive(false);
            return 0;
          }
          return prev-1;
        });
      },1000);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
    }
    return ()=> { if (intervalRef.current) clearInterval(intervalRef.current); };
  },[isActive]);

  const startTimer = async () => {
    const now = Math.floor(Date.now()/1000);
    await AsyncStorage.setItem('timerStart', now.toString());
    setIsActive(true);
  };

  const resetTimer = async () => {
    await AsyncStorage.removeItem('timerStart');
    setIsActive(false);
    setSecondsLeft(DAY_SECONDS);
  };

  const grantPoints = async () => {
    try {
      const p = await AsyncStorage.getItem('points');
      const current = p ? Number(p) : 0;
      const m = Number(await AsyncStorage.getItem('boostMultiplier')) || 1;
      const added = POINTS_ON_COMPLETE * m;
      const updated = current + added;
      await AsyncStorage.setItem('points', String(updated));
      Alert.alert('مبروك!', `حصلت على ${added} نقطة.`);
    } catch (err) { console.error(err); }
  };

  const formatTime = (s) => {
    const h = Math.floor(s/3600); const m = Math.floor((s%3600)/60); const sec = s%60;
    const pad = n => String(n).padStart(2,'0');
    return `${pad(h)}:${pad(m)}:${pad(sec)}`;
  };

  return (
    <View style={styles.page}>
      <View style={styles.card}>
        <Text style={styles.header}>عداد 24 ساعة</Text>
        <Text style={styles.timerText}>{formatTime(secondsLeft)}</Text>
        <Progress.Bar progress={(DAY_SECONDS - secondsLeft)/DAY_SECONDS} width={300} height={10} />
        <View style={styles.buttonsRow}>
          <TouchableOpacity style={[styles.btn, isActive?styles.btnPause:styles.btnStart]} onPress={() => { if(!isActive) startTimer(); else setIsActive(false); }}>
            <Text style={styles.btnText}>{isActive ? 'إيقاف' : 'ابدأ'}</Text>
          </TouchableOpacity>

          <TouchableOpacity style={[styles.btn, styles.btnLight]} onPress={resetTimer}>
            <Text style={styles.btnTextLight}>إعادة تعيين</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  page:{flex:1,backgroundColor:'#f2f6ff',alignItems:'center',justifyContent:'center'},
  card:{width:'92%',backgroundColor:'#fff',borderRadius:20,padding:18,alignItems:'center',shadowColor:'#000',shadowOpacity:0.08,shadowRadius:10,elevation:6},
  header:{fontSize:20,fontWeight:'700',marginBottom:12},
  timerText:{fontSize:28,fontWeight:'800',color:'#111',marginVertical:10},
  buttonsRow:{flexDirection:'row',marginTop:18,width:'100%',justifyContent:'space-around'},
  btn:{paddingVertical:12,paddingHorizontal:26,borderRadius:12},
  btnStart:{backgroundColor:'#3463f7'},
  btnPause:{backgroundColor:'#ff6b6b'},
  btnLight:{backgroundColor:'#f1f3f6'},
  btnText:{color:'#fff',fontWeight:'700',fontSize:16},
  btnTextLight:{color:'#333',fontWeight:'700',fontSize:16}
});

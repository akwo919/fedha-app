import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';

export default function ResultScreen({ route, navigation }) {
  const { score } = route.params || { score: 0 };
  return (
    <View style={styles.container}>
      <Text style={styles.title}>انتهت المسابقة 🎉</Text>
      <Text style={styles.score}>مجموعك: {score}</Text>
      <TouchableOpacity style={styles.btn} onPress={() => navigation.navigate('Home')}>
        <Text>العودة للرئيسية</Text>
      </TouchableOpacity>
    </View>
  );
}
const styles = StyleSheet.create({
  container:{flex:1,justifyContent:'center',alignItems:'center'},
  title:{fontSize:28,marginBottom:20},
  score:{fontSize:22,marginBottom:20},
  btn:{backgroundColor:'#ddd',padding:12,borderRadius:8}
});

import React, {useEffect, useState} from 'react';
import {View, Text, TouchableOpacity, StyleSheet} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function HomeScreen({navigation}) {
  const [points,setPoints]=useState(0);
  useEffect(()=>{ (async()=>{ const p=await AsyncStorage.getItem('points'); setPoints(p?Number(p):0); })(); },[]);

  return (
    <View style={styles.container}>
      <Text style={styles.welcome}>مرحبًا بك في تطبيق الفضة</Text>
      <Text style={styles.points}>رصيدك: {points} نقطة</Text>

      <View style={styles.row}>
        <TouchableOpacity style={styles.card} onPress={()=>navigation.navigate('Timer')}>
          <Text style={styles.cardText}>العداد ⏱</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.card} onPress={()=>navigation.navigate('Boost')}>
          <Text style={styles.cardText}>مضاعفة النقاط ⚡</Text>
        </TouchableOpacity>
      </View>

      <View style={styles.row}>
        <TouchableOpacity style={styles.cardWide} onPress={()=>navigation.navigate('Transfer')}>
          <Text style={styles.cardText}>تحويل النقاط 🔄</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.card} onPress={()=>navigation.navigate('Payment')}>
          <Text style={styles.cardText}>السحب 💳</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.card} onPress={()=>navigation.navigate('Agents')}>
          <Text style={styles.cardText}>الوكلاء 🧑‍💼</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.quizBtn} onPress={()=>navigation.navigate('Quiz')}>
        <Text style={{color:'#fff',fontWeight:'700'}}>ابدأ المسابقة</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles=StyleSheet.create({
  container:{flex:1,padding:20,backgroundColor:'#fff'},
  welcome:{fontSize:22,fontWeight:'700',textAlign:'center',marginBottom:6},
  points:{textAlign:'center',marginBottom:20,fontSize:16},
  row:{flexDirection:'row',justifyContent:'space-between',marginBottom:12},
  card:{flex:1,backgroundColor:'#f7f7f7',padding:18,marginHorizontal:6,borderRadius:12,alignItems:'center',justifyContent:'center'},
  cardWide:{flex:2,backgroundColor:'#f7f7f7',padding:18,marginHorizontal:6,borderRadius:12,alignItems:'center',justifyContent:'center'},
  cardText:{fontWeight:'700'},
  quizBtn:{backgroundColor:'#d4af37',padding:14,borderRadius:10,alignItems:'center',marginTop:20}
});

import React, {useState} from 'react';
import {View, Text, TextInput, TouchableOpacity, StyleSheet, Image} from 'react-native';

export default function LoginScreen({navigation}) {
  const [phone, setPhone] = useState('');
  const [countryCode, setCountryCode] = useState('+964');

  return (
    <View style={styles.container}>
      <Image source={require('../assets/icon.png')} style={styles.logo} />
      <Text style={styles.title}>تسجيل الدخول</Text>

      <View style={styles.phoneRow}>
        <Text style={styles.country}>{countryCode}</Text>
        <TextInput
          style={styles.input}
          placeholder="رقم الهاتف"
          keyboardType="phone-pad"
          value={phone}
          onChangeText={setPhone}
        />
      </View>

      <TouchableOpacity
        style={styles.btn}
        onPress={() => {
          navigation.navigate('OTP', { phone, countryCode });
        }}>
        <Text style={styles.btnText}>إرسال الرمز</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container:{flex:1,backgroundColor:'#fff',alignItems:'center',padding:20,justifyContent:'center'},
  logo:{width:100,height:100,marginBottom:10},
  title:{fontSize:22,fontWeight:'700',marginBottom:20},
  phoneRow:{flexDirection:'row',width:'100%',alignItems:'center',marginBottom:20},
  country:{padding:12,borderWidth:1,borderColor:'#ddd',borderRadius:8,marginRight:8},
  input:{flex:1,borderWidth:1,borderColor:'#ddd',borderRadius:8,padding:12},
  btn:{backgroundColor:'#333',paddingVertical:14,paddingHorizontal:32,borderRadius:10},
  btnText:{color:'#fff',fontWeight:'700'}
});

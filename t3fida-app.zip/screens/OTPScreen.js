import React, {useRef, useState} from 'react';
import {View, Text, TextInput, TouchableOpacity, StyleSheet, Alert} from 'react-native';

export default function OTPScreen({route, navigation}) {
  const {phone} = route.params || {};
  const [d1,setD1]=useState(''); const [d2,setD2]=useState('');
  const [d3,setD3]=useState(''); const [d4,setD4]=useState('');
  const r1 = useRef(); const r2 = useRef(); const r3 = useRef(); const r4 = useRef();

  const handleConfirm = () => {
    const code = `${d1}${d2}${d3}${d4}`;
    if (code === '1234') {
      navigation.replace('Home');
    } else {
      Alert.alert('رمز خاطئ', 'الرمز الصحيح للتجربة هو 1234');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>أدخل رمز التحقق</Text>
      <Text style={styles.sub}>أرسلنا رمزًا إلى رقمك</Text>
      <View style={styles.row}>
        <TextInput ref={r1} style={styles.box} keyboardType="numeric" maxLength={1} value={d1} onChangeText={t=>{setD1(t); if(t) r2.current.focus();}} />
        <TextInput ref={r2} style={styles.box} keyboardType="numeric" maxLength={1} value={d2} onChangeText={t=>{setD2(t); if(t) r3.current.focus();}} />
        <TextInput ref={r3} style={styles.box} keyboardType="numeric" maxLength={1} value={d3} onChangeText={t=>{setD3(t); if(t) r4.current.focus();}} />
        <TextInput ref={r4} style={styles.box} keyboardType="numeric" maxLength={1} value={d4} onChangeText={t=>{setD4(t); if(t) handleConfirm();}} />
      </View>
      <TouchableOpacity style={styles.btn} onPress={handleConfirm}><Text style={styles.btnText}>تأكيد</Text></TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container:{flex:1,backgroundColor:'#fff',alignItems:'center',justifyContent:'center',padding:20},
  title:{fontSize:22,fontWeight:'700'},
  sub:{marginTop:6,marginBottom:20,color:'#666'},
  row:{flexDirection:'row',justifyContent:'space-between',width:'70%'},
  box:{width:50,height:50,borderWidth:1,borderColor:'#ddd',borderRadius:8,textAlign:'center',fontSize:22},
  btn:{marginTop:30,backgroundColor:'#333',paddingVertical:12,paddingHorizontal:30,borderRadius:8},
  btnText:{color:'#fff',fontWeight:'700'}
});

import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';

import LoginScreen from './screens/LoginScreen';
import OTPScreen from './screens/OTPScreen';
import HomeScreen from './screens/HomeScreen';
import TimerScreen from './screens/TimerScreen';
import BoostScreen from './screens/BoostScreen';
import TransferScreen from './screens/TransferScreen';
import PaymentScreen from './screens/PaymentScreen';
import AgentsScreen from './screens/AgentsScreen';
import QuizScreen from './screens/QuizScreen';
import ResultScreen from './screens/ResultScreen';

const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login" screenOptions={{headerShown:true}}>
        <Stack.Screen name="Login" component={LoginScreen} options={{headerShown:false}} />
        <Stack.Screen name="OTP" component={OTPScreen} options={{ title: 'تأكيد الرمز' }} />
        <Stack.Screen name="Home" component={HomeScreen} options={{ title: 'الرئيسية' }} />
        <Stack.Screen name="Timer" component={TimerScreen} options={{ title: 'العداد' }} />
        <Stack.Screen name="Boost" component={BoostScreen} options={{ title: 'مضاعفة النقاط' }} />
        <Stack.Screen name="Transfer" component={TransferScreen} options={{ title: 'تحويل النقاط' }} />
        <Stack.Screen name="Payment" component={PaymentScreen} options={{ title: 'السحب / الدفع' }} />
        <Stack.Screen name="Agents" component={AgentsScreen} options={{ title: 'الوكلاء' }} />
        <Stack.Screen name="Quiz" component={QuizScreen} options={{ title: 'مسابقة' }} />
        <Stack.Screen name="Result" component={ResultScreen} options={{ title: 'النتيجة' }} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
